#import "AdColonyTypes.h"

/**
 AdColony ad request object
 */
@interface AdColonyAdRequestError : NSError
@end
